#!/bin/bash -u
cd "$(dirname "$0")"
base=$(pwd)
prefix="$base/opt"
mkdir -p "$prefix"

cd "$base"
if [[ ! -e fftw-3.3.8 ]]; then
    wget http://www.fftw.org/fftw-3.3.8.tar.gz -O fftw.tar.gz
    if [[ "$(sha256sum fftw.tar.gz | awk '{print $1}')" != "6113262f6e92c5bd474f2875fa1b01054c4ad5040f6b0da7c03c98821d9ae303" ]]; then
        echo "fftw failed checksum"
        exit 1
    fi
    tar -xf fftw.tar.gz
    rm fftw.tar.gz
fi
cd fftw-3.3.8
./configure --enable-single --prefix="$prefix"
make -j4
make install

cd "$base"
if [[ ! -e openmp-7.0.0.src ]]; then
    wget https://releases.llvm.org/7.0.0/openmp-7.0.0.src.tar.xz -O openmp.tar.xz
    if [[ "$(sha256sum openmp.tar.xz | awk '{print $1}')" != "30662b632f5556c59ee9215c1309f61de50b3ea8e89dcc28ba9a9494bba238ff" ]]; then
        echo "openmp failed checksum"
        exit 1
    fi
    tar -xf openmp.tar.xz
    rm openmp.tar.xz
fi
cd openmp-7.0.0.src && mkdir -p build && cd build
cmake ..  -DCMAKE_INSTALL_PREFIX="$prefix"
make -j4
make install

cd "$base"
git clone https://github.com/talonvoice/libfvad.git
cd libfvad
git checkout ee69951e7ec6ed3a0caf547f35f103280b9831de
[[ ! -e configure ]] && autoreconf -i
./configure --disable-shared --enable-static --prefix "$prefix"
make -j4
make install

cd "$base"
git clone https://github.com/intel/mkl-dnn.git
cd mkl-dnn
./scripts/prepare_mkl.sh
cp -av external/mklml_*/{include,lib} "$prefix"
git checkout v0.18.1
if [[ ! -e Makefile ]]; then
    cmake . -DWITH_TEST=OFF -WITH_EXAMPLE=OFF -DCMAKE_INSTALL_PREFIX="$prefix"
fi
make -j4 && make install

cd "$base"
git clone --recursive https://github.com/arrayfire/arrayfire.git
cd arrayfire && mkdir -p build && cd build
git checkout v3.6.2
CXXFLAGS=-DOS_MAC cmake .. -DCMAKE_BUILD_TYPE=Release -DAF_BUILD_CUDA=OFF -DAF_BUILD_OPENCL=OFF -DAF_BUILD_OPENCL=OFF -DAF_BUILD_EXAMPLES=OFF -DAF_WITH_GRAPHICS=OFF -DAF_WITH_IMAGEIO=OFF -DAF_WITH_LOGGING=OFF -DBUILD_TESTING=OFF -DCMAKE_INSTALL_PREFIX="$prefix"
make -j4 && make install

cd "$base"
git clone --recursive https://github.com/facebookresearch/flashlight.git
cd flashlight && mkdir -p build && cd build
cmake .. -DCMAKE_BUILD_TYPE=Release -DFLASHLIGHT_BACKEND=CPU -DFL_BUILD_DISTRIBUTED=OFF -DFL_BUILD_TESTS=OFF -DFL_BUILD_EXAMPLES=OFF -DCMAKE_INSTALL_PREFIX="$prefix"
make -j4 && make install

# TODO: kenlm linked boost and liblzma from /usr/local on my machine
cd "$base"
git clone https://github.com/kpu/kenlm.git
cd kenlm && git checkout e47088ddfae810a5ee4c8a9923b5f8071bed1ae8 && mkdir -p build && cd build
cmake .. -DBUILD_TESTING=NO -DCMAKE_INSTALL_PREFIX="$prefix"
make -j4 && make install

cd "$base"
git clone https://github.com/google/glog.git
cd glog && ./autogen.sh && ./configure --disable-shared --enable-static --prefix "$prefix"
make -j4 && make install

cd "$base"
git clone https://github.com/gflags/gflags.git
cd gflags
cmake . -DCMAKE_INSTALL_PREFIX="$prefix"
make -j4 && make install

cd "$base"
git clone https://github.com/erikd/libsndfile.git
cd libsndfile
git checkout 5056a77fdae85f96eee4dff82af462db5a5c341e
./autogen.sh
./configure --enable-werror --prefix="$prefix"
make -j4
make install

cd "$base"
# FIXME: upstream wav2letter doesn't support mac
# git clone https://github.com/facebookresearch/wav2letter.git
git clone https://github.com/realdoug/wav2letter.git
cd wav2letter && mkdir -p build && cd build
export KENLM_ROOT_DIR="$base/kenlm"
export LIBRARY_PATH="$prefix/lib"
cmake .. -DW2L_BUILD_TESTS=NO -DCMAKE_BUILD_TYPE=Release -DW2L_CRITERION_BACKEND=CPU -DCMAKE_INSTALL_PREFIX="$prefix" -DMKL_LIBRARIES='-lmkldnn -liomp5' -DCMAKE_EXE_LINKER_FLAGS="-L'$prefix'" -DW2L_BUILD_DISTRIBUTED=OFF -DFFTW_USE_STATIC_LIBS=ON
make -j2
