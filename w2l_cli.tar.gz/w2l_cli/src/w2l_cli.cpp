// g++ -std=c++17 -L../../opt/lib/ -I../../opt/include -L../../kenlm/build/lib -I.. w2l_cli.cpp libw2l.a -laf -lflashlight -lfftw3 -lglog -lgflags -lmkldnn -lkenlm -lkenlm_util -lomp -lstdc++ -llzma -lbz2 -lz -framework Accelerate -framework AudioToolbox -framework CoreFoundation -lfvad -o w2l

#include <AudioToolbox/AudioQueue.h>
#include <CoreFoundation/CoreFoundation.h>
#include <condition_variable>
#include <cstdio>
#include <iostream>
#include <fvad.h>
#include <list>
#include <mutex>
#include <stdlib.h>
#include <string>
#include <vector>

#include "w2l.h"

static w2l_engine *engine = NULL;
static w2l_decoder *decoder = NULL;

static double frame_time = 0;
const float pre_activity     = 0.010;
const float activity_timeout = 0.010;
const float minimum_activity = 0.025;
const int activity_mode = 0;
const int frame_size = 480;

typedef struct audio_frame {
    bool valid;
    std::vector<float> samples;
} audio_frame;

struct state {
    Fvad *vad;
    std::mutex lock;
    std::condition_variable cond;
    std::list<audio_frame> pre_frames;
    std::list<audio_frame> frames;
    std::list<std::list<audio_frame> > clips;
};
struct state state = {0};

void _audio_cb(void *user, AudioQueueRef queue, AudioQueueBufferRef buffer, const AudioTimeStamp *start,
        uint32_t count, const AudioStreamPacketDescription *descs) {
    int sample_count = buffer->mAudioDataBytesCapacity / sizeof(float);
    float *samples = (float *)buffer->mAudioData;

    std::vector<float> data(samples, samples + sample_count);

    std::vector<int16_t> vsamples(sample_count);
    for (size_t i = 0; i < sample_count; i++) {
        vsamples[i] = data[i] * INT16_MAX;
    }

    int vad = fvad_process(state.vad, &vsamples[0], sample_count);
    if (vad < 0) {
        std::cout << "vad failed: " << vad << std::endl;
        abort();
    }
    bool valid = !!vad;

    state.lock.lock();
    if (valid || state.frames.size() * frame_time >= minimum_activity) {
        state.frames.push_back({valid, std::move(data)});
        if (!valid) {
            int invalid = 0;
            for (auto frame=state.frames.rbegin(); frame != state.frames.rend(); ++frame) {
                if (frame->valid) break;
                invalid++;
            }
            if (invalid * frame_time >= activity_timeout) {
                auto frames = std::move(state.pre_frames);
                frames.splice(frames.end(), state.frames);
                state.clips.push_back(std::move(frames));
                state.pre_frames.clear();
                state.frames.clear();
                state.cond.notify_one();
            }
        }
    } else {
        state.frames.clear();
        state.pre_frames.push_back({valid, std::move(data)});
        while (state.pre_frames.size() - 1 >= frame_time * pre_activity) {
            state.pre_frames.pop_front();
        }
    }
    state.lock.unlock();
    AudioQueueEnqueueBuffer(queue, buffer, 0, NULL);
    return;
}

void usage_exit(const char *cmd) {
    fprintf(stderr, "Usage: %s emit   <acoustic model> <tokens.txt>\n", cmd);
    fprintf(stderr, "Usage: %s decode <acoustic model> <tokens.txt> <language model> <lexicon>\n", cmd);
    exit(1);
}

int main(int argc, char **argv) {
    if (argc < 2) usage_exit(argv[0]);
    std::string cmd = argv[1];
    std::string am_path, tokens_path, lm_path, lexicon_path;
    if (cmd == "emit") {
        if (argc < 4) {
            fprintf(stderr, "Error: Expected 3 arguments\n");
            usage_exit(argv[0]);
        }
    } else if (cmd == "decode") {
        if (argc < 6) {
            fprintf(stderr, "Error: Expected 5 arguments\n");
            usage_exit(argv[0]);
        }
        lm_path = argv[4];
        lexicon_path = argv[5];
    } else {
        fprintf(stderr, "Error: Unknown command: %s\n", argv[1]);
        usage_exit(argv[0]);
    }
    am_path = argv[2];
    tokens_path = argv[3];

    engine = w2l_engine_new(am_path.c_str(), tokens_path.c_str());
    if (cmd == "decode") {
        decoder = w2l_decoder_new(engine, lm_path.c_str(), lexicon_path.c_str());
    }

    state.vad = fvad_new();
    fvad_set_sample_rate(state.vad, 16000);

    AudioStreamBasicDescription format = {
        .mSampleRate = 16000,
        .mFormatID = kAudioFormatLinearPCM,
        .mFormatFlags = kAudioFormatFlagsNativeFloatPacked,
        .mFramesPerPacket = 1,
        .mChannelsPerFrame = 1,
        .mBytesPerFrame = sizeof(float),
        .mBytesPerPacket = sizeof(float),
        .mBitsPerChannel = sizeof(float) * 8,
    };
    frame_time = (double)format.mSampleRate / (double)frame_size / 1000.0;
    AudioQueueRef queue;
    AudioQueueBufferRef buffer;
    OSStatus status = AudioQueueNewInput(&format, _audio_cb, NULL, NULL, kCFRunLoopCommonModes, 0, &queue);
    if (status)
        return status;
    AudioQueueAllocateBuffer(queue, frame_size * sizeof(float), &buffer);
    AudioQueueEnqueueBuffer(queue, buffer, 0, NULL);
    AudioQueueStart(queue, NULL);

    printf("[listening]\n");
    while (1) {
        std::unique_lock<std::mutex> lock(state.lock);
        while (state.clips.size() == 0) {
            state.cond.wait(lock);
        }
        auto clip = state.clips.back();
        state.clips.pop_back();
        lock.unlock();
        std::vector<float> data;
        for (auto const &frame : clip) {
            std::copy(frame.samples.begin(), frame.samples.end(), std::back_inserter(data));
        }
        w2l_emission *emission = w2l_engine_process(engine, &data[0], data.size());
        char *text = NULL;
        if (decoder) {
            text = w2l_decoder_decode(decoder, emission);
        } else {
            text = w2l_emission_text(emission);
        }
        if (strlen(text) > 0) {
            printf("%s\n", text);
        }
        free(text);
        w2l_emission_free(emission);
        lock.lock();
    }
    w2l_engine_free(engine);
    w2l_decoder_free(decoder);
}
